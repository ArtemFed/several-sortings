#ifndef HW1_BUBBLE_SORT_H
#define HW1_BUBBLE_SORT_H
#include <vector>

std::size_t  bubbleSort(std::vector<int>& vec, int n);

std::size_t  bubbleSortIversonOne(std::vector<int>& vec, int n);

std::size_t  bubbleSortIversonTwo(std::vector<int>&vec, int n);

#endif// HW1_BUBBLE_SORT_H
