#ifndef HW1_COUNTING_SORT_H
#define HW1_COUNTING_SORT_H

#include <vector>
std::size_t stableCountingSort(std::vector<int>& vec, int diffSize, int min, int n);

#endif//HW1_COUNTING_SORT_H
