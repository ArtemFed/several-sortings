#ifndef HW1_SELECTION_SORT_H
#define HW1_SELECTION_SORT_H

#include <vector>
std::size_t selectionSort(std::vector<int> &vec, int n);

#endif//HW1_SELECTION_SORT_H
