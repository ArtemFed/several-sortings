#ifndef HW1_HEAP_SORT_H
#define HW1_HEAP_SORT_H
#include "vector"

void heapSort(std::vector<int> &vec);

#endif// HW1_HEAP_SORT_H
