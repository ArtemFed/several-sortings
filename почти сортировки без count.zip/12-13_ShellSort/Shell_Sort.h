#ifndef HW1_SHELL_SORT_H
#define HW1_SHELL_SORT_H

#include <vector>

void shellSortCiur(std::vector<int> &vec, int n);

void shellSort(std::vector<int> &vec, int n);

#endif//HW1_SHELL_SORT_H
