#ifndef WH1_QUICK_SORT_H
#define WH1_QUICK_SORT_H
#include "vector"

void quickSort(std::vector<int>& vec, int left, int right);

#endif// WH1_QUICK_SORT_H
