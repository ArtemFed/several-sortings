#ifndef HW1_MERGE_SORT_H
#define HW1_MERGE_SORT_H
#include "vector"

//template<typename T>
void mergeSort(std::vector<int> &vec, std::vector<int> &vecTemp, int begin, int end);

#endif// HW1_MERGE_SORT_H
